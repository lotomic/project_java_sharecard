package hr.sharecard.database;

import java.util.ArrayList;
import java.util.List;

import hr.sharecard.types.EventInfo;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class EventsAdapter {

	public static final String DATABASE_NAME = "sharecard.db";
	public static final int DATABASE_VERSION = 1;
	public static final String TABLE = "event";
	public static final String TABLE_TIMELINE = "timeline";
	public static final String KEY = "event_id";
	
	private LocalDB localDB;
	private SQLiteDatabase db;
	private Context context;
	
	public EventsAdapter(Context c){
		context = c;
		localDB = new LocalDB(context, DATABASE_NAME, null, DATABASE_VERSION);
	}
	
	private EventsAdapter openToRead(){
		db = localDB.getReadableDatabase();
		return this;
	}
	
	private EventsAdapter openToWrite(){
		db = localDB.getWritableDatabase();
		return this;
	}
	
	private void close()
	{
		localDB.close();
	}
	
	public long insertEvent(EventInfo event){
		ContentValues values = new ContentValues();
		values.put("name", event.getEventName());
		values.put("description", event.getEventDesc());
		values.put("date", event.getEventDate());
		values.put("artifact", event.getEventArtifact());
		values.put("timeline_id",event.getTimeline_id());

		openToWrite();
		long result = db.insert(TABLE, null, values);
		
		close();
		return result;
		
		
	}
	
	public List<EventInfo> getAllEvent(){
		List<EventInfo> events = new ArrayList<EventInfo>();
		
		openToRead();
		String[] columns = new String[] {
				KEY, "name", "description", "date", "artifact","timeline_id"};
		Cursor c = db.query(TABLE, columns, null, null, null, null, null);
		
		for(c.moveToFirst(); !(c.isAfterLast()); c.moveToNext())
		{
			int id = c.getInt(c.getColumnIndex(KEY));
			String name = c.getString(c.getColumnIndex("name"));
			String desc = c.getString(c.getColumnIndex("description"));
			String date = c.getString(c.getColumnIndex("date"));
			String artifact = c.getString(c.getColumnIndex("artifact"));
			int t_id = c.getInt(c.getColumnIndex("timeline_id"));
			
			
			EventInfo event = new EventInfo();
			
			event.setEventid(id);
			event.setEventName(name);
			event.setEventDesc(desc);
			event.setEventDate(date);
			event.setEventArtifact(artifact);
			event.setTimeline_id(t_id);
			
			
			
			
			events.add(event);
		}
		close();
		return events;
		
		
	}
	
	public boolean deleteEvent(String id){
		openToWrite();
		boolean r = db.delete(TABLE, KEY + "=" + id, null) > 0;
		close();
		return r;
	}
	
	public boolean updateEvent(String id, String eventname, String eventdesc, String eventdate, String eventartifact){
		ContentValues values = new ContentValues();
		values.put("name", eventname);
		values.put("description", eventdesc);
		values.put("date", eventdate);
		values.put("artifact", eventartifact);
		
		
		openToWrite();
		boolean r = db.update(TABLE, values, KEY + "=" + id, null) > 0;
		close();
		return r;
		
	}
}

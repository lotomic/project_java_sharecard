package hr.sharecard.database;

import java.util.ArrayList;
import java.util.List;

import hr.sharecard.types.CardInfo;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * klasa kreira metode pomo�u kojih se podatci modificiraju u bazi podataka
 * @author Lorena
 *
 */
public class CardsAdapter {
	public static final String DATABASE_NAME = "sharecard.db";
	public static final int DATABASE_VERSION = 1;
	public static final String TABLE = "sharecard";
	public static final String TABLE_TIMELINE = "timeline";
	public static final String KEY = "sharecard_id";
	public static final String KEY_T = "timeline_id";
	
	private LocalDB localDB;
	private SQLiteDatabase db;
	private Context context;
	
	/**
	 * metoda za kreiranje baze podataka
	 * @param c
	 */
	public CardsAdapter(Context c){
		context = c;
		localDB = new LocalDB(context, DATABASE_NAME, null, DATABASE_VERSION);
	}
	
	/**
	 * metoda otvara bazu podataka za �itanje
	 * @return
	 */
	private CardsAdapter openToRead(){
		db = localDB.getReadableDatabase();
		return this;
	}
	/**
	 * metoda otvara bazu podataka za pisanje
	 * @return
	 */
	private CardsAdapter openToWrite(){
		db = localDB.getWritableDatabase();
		return this;
	}
	/**
	 * metoda za zatvaranje baze podataka
	 */
	private void close()
	{
		localDB.close();
	}
	/**
	 * metoda za unos nove vizitke u bazu podataka
	 * @param card
	 * @return
	 */
	public long insertCard(CardInfo card){
		
		ContentValues values = new ContentValues();
		values.put("name", card.getName());
		values.put("surname", card.getSurname());
		values.put("company", card.getCompany());
		values.put("phone", card.getPhone());
		values.put("email", card.getEmail());
		values.put("pic", card.getPic());
		values.put("type", "1");
		
		openToWrite();
		long result = db.insert(TABLE, null, values);
		
		ContentValues tvalues = new ContentValues();
		tvalues.put(KEY, result);
		tvalues.put("name", card.getSurname());
		
		db.insert(TABLE_TIMELINE, null, tvalues);
		
		close();
		return result;
	}
	
	/**
	 * metoda za unos nove vizitke u bazu podataka
	 * @param card
	 * @return
	 */
	public long sharedCard(CardInfo card){
		
		ContentValues values = new ContentValues();
		values.put("name", card.getName());
		values.put("surname", card.getSurname());
		values.put("company", card.getCompany());
		values.put("phone", card.getPhone());
		values.put("email", " ");
		values.put("pic", " ");
		values.put("type", "2");
		
		openToWrite();
		long result = db.insert(TABLE, null, values);
		close();
		return result;
	}	/**
	 * metoda koja slu�i za dohva�anje svih vizitki u bazi podataka
	 * @return
	 */
	
	public List<CardInfo> getMyCards()
	{
		List<CardInfo> cards = new ArrayList<CardInfo>();
		
		openToRead();

		Cursor c = db.rawQuery("select * from sharecard where type='1'", null);
		
		for(c.moveToFirst(); !(c.isAfterLast()); c.moveToNext())
		{
			int id = c.getInt(c.getColumnIndex(KEY));
			String name = c.getString(c.getColumnIndex("name"));
			String surname = c.getString(c.getColumnIndex("surname"));
			String phone = c.getString(c.getColumnIndex("phone"));
			String company = c.getString(c.getColumnIndex("company"));
			String email = c.getString(c.getColumnIndex("email"));
			String pic = c.getString(c.getColumnIndex("pic"));
			
			CardInfo card = new CardInfo();
			
			card.setId(id);
			card.setName(name);
			card.setSurname(surname);
			card.setPhone(phone);
			card.setCompany(company);
			card.setEmail(email);
			card.setPic(pic);
			
			
			cards.add(card);
		}
		close();
		return cards;
	}
	/**
	 * metoda koja slu�i za dohva�anje svih vizitki u bazi podataka
	 * @return
	 */
	
	public List<CardInfo> getAllCards()
	{
		List<CardInfo> cards = new ArrayList<CardInfo>();
		
		openToRead();
		Cursor c = db.rawQuery("select * from sharecard", null);
		
		for(c.moveToFirst(); !(c.isAfterLast()); c.moveToNext())
		{
			int id = c.getInt(c.getColumnIndex(KEY));
			String name = c.getString(c.getColumnIndex("name"));
			String surname = c.getString(c.getColumnIndex("surname"));
			String phone = c.getString(c.getColumnIndex("phone"));
			String company = c.getString(c.getColumnIndex("company"));
			String email = c.getString(c.getColumnIndex("email"));
			String pic = c.getString(c.getColumnIndex("pic"));
			
			CardInfo card = new CardInfo();
			
			card.setId(id);
			card.setName(name);
			card.setSurname(surname);
			card.setPhone(phone);
			card.setCompany(company);
			card.setEmail(email);
			card.setPic(pic);
			
			
			cards.add(card);
		}
		close();
		return cards;
	}
	/**
	 * metoda za brisanje vizitke iz baze podataka
	 * @param id
	 * @return
	 */
	public boolean deleteCard(String id){
		openToWrite();
		boolean r = db.delete(TABLE, KEY + "=" + id, null) > 0;
		boolean r2 = db.delete(TABLE_TIMELINE, KEY_T + "=" + id, null) > 0;
		close();
		return r;
	}
	/**
	 * metoda za a�uriranje vizitke u bazi podataka
	 * @param id
	 * @param name
	 * @param surname
	 * @param company
	 * @param phone
	 * @return
	 */
	public boolean updateCard(String id, String name, String surname, String company, String phone, String pic){
		ContentValues values = new ContentValues();
		values.put("name", name);
		values.put("surname", surname);
		values.put("company", company);
		values.put("phone", phone);
		values.put("pic", pic);
		
		openToWrite();
		boolean r = db.update(TABLE, values, KEY + "=" + id, null) > 0;
		close();
		return r;
	}

	
	
}

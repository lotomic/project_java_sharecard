package hr.sharecard.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
/**
 * klasa za kreiranje baze podataka
 * @author Lorena
 *
 */
public class LocalDB extends SQLiteOpenHelper{

	public LocalDB(Context context, String name, CursorFactory factory, int version) {
		super(context, name, factory, version);
	}
	/**
	 * metoda za kreiranje tablica u bazi podatka
	 * @param db
	 * 
	 */
	public void onCreate(SQLiteDatabase db){
		String sqlQuery = "CREATE TABLE contacts (contacts_id INTEGER PRIMARY KEY, name TEXT, description TEXT);";
		String sqlQuery2 = "CREATE TABLE event (event_id INTEGER PRIMARY KEY, date TEXT, name TEXT, description TEXT, artifact TEXT, timeline_id INT);";
		String sqlQuery3 = "CREATE TABLE sharecard (sharecard_id INTEGER PRIMARY KEY, name TEXT, surname TEXT, phone TEXT, company TEXT, email TEXT, pic TEXT, type INT);";
		String sqlQuery4 = "CREATE TABLE timeline (timeline_id INTEGER PRIMARY KEY, sharecard_id INT, name TEXT);";
		
		db.execSQL(sqlQuery);
		db.execSQL(sqlQuery2);
		db.execSQL(sqlQuery3);
		db.execSQL(sqlQuery4);
	}
	/**
	 * metoda koja definira akcije prilikom a�uriranja baze podataka
	 * @param db
	 * @param oldVersion
	 * @param newVersion
	 */
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		
	}
	
}

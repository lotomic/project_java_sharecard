package hr.sharecard;

import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.view.Window;

public class SettingsActivity extends PreferenceActivity implements OnSharedPreferenceChangeListener {
	
	
	/**
	 * onCreate metoda se poziva odmah nakon startanja klase. 
	 * Unutar ove metode pozivaju se druge metode i inicijaliziraiju varijable.
	 * @param savedInstanceState
	 * @return void
	 */
	
	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		super.onCreate(savedInstanceState);		
		
		addPreferencesFromResource(R.xml.xml_settings);
		
		getPreferenceScreen()
			.getSharedPreferences()
				.registerOnSharedPreferenceChangeListener(this);
	}

	/**
	 * onSharedPreferenceChanged slu�i za izmjenu podataka unutar settingsactivity klase.
	 * @param arg0, arg1
	 * @return void
	 */
	
	@Override
	public void onSharedPreferenceChanged(SharedPreferences arg0, String arg1) {
		// TODO Auto-generated method stub
		
	}

}

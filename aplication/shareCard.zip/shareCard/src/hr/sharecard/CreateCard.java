package hr.sharecard;



import hr.sharecard.database.CardsAdapter;
import hr.sharecard.types.CardInfo;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;


/**
 * Klasa CreateCard omogu�ava unos nove vizitke. Podatci se zapisuju u editText polja �ije se vrijednosti spremaju u string 
 * te u listu kako bi se pohranili u bazu podataka. Gumb save poziva metodu spremanja u bazu podataka, a gumb Cancel otkazuje navedenu radnju.
 * 
 * @author Lorena
 *
 */

public class CreateCard extends Activity{
	
	
	private static final int RESULT_LOAD_IMAGE = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_createcard);
		final Context context = this;
		final int RESULT_LOAD_IMAGE = 0;
		
		
		

		Button btnSave = (Button)findViewById(R.id.btnSave);
		btnSave.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {		
				
				EditText txtName = (EditText) findViewById(R.id.editName);
				EditText txtSurname = (EditText) findViewById(R.id.editSurname);
				EditText txtCompany = (EditText) findViewById(R.id.editCompany);
				EditText txtPhone = (EditText) findViewById(R.id.editPhone);
				EditText txtEmail = (EditText) findViewById(R.id.editEmail);
				EditText txtPic = (EditText) findViewById(R.id.picpath);
				
				String name = txtName.getText().toString();
				String surname = txtSurname.getText().toString();
				String company = txtCompany.getText().toString();
				String phone = txtPhone.getText().toString();
				String email = txtEmail.getText().toString();
				String pic = txtPic.getText().toString();

				CardInfo newCard = new CardInfo();
				newCard.setName(name);
				newCard.setSurname(surname);
				newCard.setCompany(company);
				newCard.setPhone(phone);
				newCard.setEmail(email);
				newCard.setPic(pic);
					
				
				CardsAdapter cardsAdapter = new CardsAdapter(context);
				cardsAdapter.insertCard(newCard);
				
				setResult(RESULT_OK, null);
				finish();
				
			}
			
		});
		Button btnCancel = (Button)findViewById(R.id.btnCancel);
		
		btnCancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(v.getId() == R.id.btnCancel){
					finish();
				
				}
			}
		});
			
		Button btnImg = (Button)findViewById(R.id.btnImg);
		
		btnImg.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				Intent i = new Intent(
				Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
				 
				startActivityForResult(i, RESULT_LOAD_IMAGE);
				
			}
		});
	}
	/**
	 * metoda slu�i za unos slike prilikom kreiranja nove vizitke
	 * @param requestCode
	 * @param resultCode
	 * @param data
	 * @return void
	 */
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
         
        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };
            
            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();
 
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();
             
            ImageView imageView = (ImageView) findViewById(R.id.editImg);
            imageView.setImageBitmap(BitmapFactory.decodeFile(picturePath));
            
            EditText picpath = (EditText) findViewById(R.id.picpath);
            picpath.setText(picturePath);
         
        }
     
     
    }

}

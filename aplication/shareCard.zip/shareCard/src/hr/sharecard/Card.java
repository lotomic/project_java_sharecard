package hr.sharecard;

import hr.sharecard.database.CardsAdapter;

import java.io.Serializable;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Html;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;

public class Card extends Activity{
	
	
	private static final int RESULT_LOAD_IMAGE = 0;

	
	/**
	 * onCreate metoda se poziva odmah nakon startanja klase. 
	 * Unutar ove metode pozivaju se druge metode i inicijaliziraiju varijable.
	 * @param savedInstanceState
	 * @return void
	 */
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_singlecard);
		final int RESULT_LOAD_IMAGE = 0;
		

        Bundle bn = new Bundle();
        bn = getIntent().getExtras();
        Serializable selectedFromList = bn.getSerializable("selectedFromList");
        String[] parts = selectedFromList.toString().split(",");
        String[] idparts = parts[0].split("=");
        String[] nameparts = parts[5].split("=");
        String[] surnameparts = parts[1].split("=");
        String[] picparts = parts[3].split("=");
        String[] companyparts = parts[4].split("=");
        String[] phoneparts = parts[2].split("=");
              	
      	final String id = idparts[1];
      	final String oldName = nameparts[1].replace("}", "");
      	final String oldSurname = surnameparts[1];
      	final String oldCompany = companyparts[1];
      	final String oldPhone = phoneparts[1];
      	final String oldPic = picparts[1];

      	//Toast.makeText(Card.this, String.format("Id:"+id+" name:"+oldName+" surname:"+oldSurname+" pic:"+oldPic+" company:"+oldCompany+" phone:"+oldPhone),Toast.LENGTH_LONG).show();	
      	final Context context = this;
      	
      	
      	TextView name= (TextView) findViewById(R.id.showName);
      	name.setText(oldName);
      	TextView surname= (TextView) findViewById(R.id.showSurname);
      	surname.setText(oldSurname);
      	TextView company= (TextView) findViewById(R.id.showCompany);
      	company.setText(oldCompany);
      	TextView phone= (TextView) findViewById(R.id.showPhone);
      	phone.setText(oldPhone);
      	ImageView pic = (ImageView) findViewById(R.id.showPic);
      	pic.setImageBitmap(BitmapFactory.decodeFile(oldPic));
      	
		Button btnEdit = (Button)findViewById(R.id.btnEdit);
		btnEdit.setOnClickListener(new OnClickListener() {
			/**
			 * onClick metoda poziva se nakon klika na navedeni gumb.
			 * @param v
			 * @return void
			 */
			
			@Override
			public void onClick(View v) {
				final Dialog myDialog = new Dialog(Card.this);	
				myDialog.setContentView(R.layout.activity_editcard);
				myDialog.setTitle("Editing card");
				myDialog.setCancelable(true);
				myDialog.show();
				
			
				final EditText txtName = (EditText)myDialog.findViewById(R.id.editName);
				final EditText txtSurname = (EditText)myDialog.findViewById(R.id.editSurname);
				final EditText txtCompany = (EditText)myDialog.findViewById(R.id.editCompany);
				final EditText txtPhone = (EditText)myDialog.findViewById(R.id.editPhone);
				final EditText txtPic = (EditText)myDialog.findViewById(R.id.editPicpath);
				final ImageView picture = (ImageView)myDialog.findViewById(R.id.editImg);
				
				txtName.setText(oldName);
				txtSurname.setText(oldSurname);
				txtCompany.setText(oldCompany);
				txtPhone.setText(oldPhone);
				txtPic.setText(oldPic);
				picture.setImageBitmap(BitmapFactory.decodeFile(oldPic));
				
				Button btnSave = (Button)myDialog.findViewById(R.id.btnSave);
				btnSave.setOnClickListener(new OnClickListener() {
					
					/**
					 * onClick metoda poziva se nakon klika na navedeni gumb.
					 * @param v
					 * @return void
					 */
					
					@Override
					public void onClick(View v) {
						CardsAdapter cardsAdapter = new CardsAdapter(context);
						String newName = txtName.getText().toString();
						String newSurname = txtSurname.getText().toString();
						String newCompany = txtCompany.getText().toString();
						String newPhone = txtPhone.getText().toString();
						String newPic = txtPic.getText().toString();
						boolean ok = cardsAdapter.updateCard(id, newName, newSurname, newCompany, newPhone, newPic);
						Toast.makeText(context, ok ? "Card updated!" : "Error", Toast.LENGTH_LONG).show();
						myDialog.dismiss();
						
						setResult(RESULT_OK, null);
						finish();
					}
					
				});
				
				Button btnCancel = (Button)myDialog.findViewById(R.id.btnCancel);
				/**
				 * onClick metoda poziva se nakon klika na navedeni gumb.
				 * @param v
				 * @return void
				 */
				btnCancel.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						myDialog.dismiss();
					}
				});
				
			}
		});
		Button btnDelete = (Button)findViewById(R.id.btnDelete);
		btnDelete.setOnClickListener(new OnClickListener() {
			/**
			 * onClick metoda poziva se nakon klika na navedeni gumb.
			 * @param v
			 * @return void
			 */
			@Override
			public void onClick(View v) {
				CardsAdapter cardsAdapter = new CardsAdapter(context);
				cardsAdapter.deleteCard(id);

				setResult(RESULT_OK, null);
				finish();
			}
		});
		
		Button btnTimeline = (Button)findViewById(R.id.btnTimeline);
		btnTimeline.setOnClickListener(new OnClickListener() {
			/**
			 * onClick metoda poziva se nakon klika na navedeni gumb.
			 * @param v
			 * @return void
			 */
			@Override
			public void onClick(View v) {
				Intent i = new Intent(context, Timeline.class);
				i.putExtra("id", id);
				startActivity(i);	
			}
			
		});
		
		Button btnShare = (Button)findViewById(R.id.btnShare);
		btnShare.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent sendIntent = new Intent();
				sendIntent.setAction(Intent.ACTION_SEND);
				sendIntent.setType("text/plain");
				sendIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Name:"+oldName+",Surname:"+oldName+",Company:"+oldCompany+",Phone:"+oldPhone);
				startActivity(sendIntent);
				
			}
		});
		
		Button btnMail = (Button)findViewById(R.id.btnMail);
		btnMail.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				final Dialog myDialog = new Dialog(Card.this);	
				myDialog.setContentView(R.layout.activity_mail);
				myDialog.setTitle("Mail card");
				myDialog.setCancelable(true);
				myDialog.show();

				final EditText txtName = (EditText)myDialog.findViewById(R.id.emailTo);
				
				Button btnSave = (Button)myDialog.findViewById(R.id.btnSave);
				btnSave.setOnClickListener(new OnClickListener() {
					
					/**
					 * onClick metoda poziva se nakon klika na navedeni gumb.
					 * @param v
					 * @return void
					 */
					
					@Override
					public void onClick(View v) {
						final Intent shareIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"+txtName.getText().toString()));
						shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Hi, this is my shareCard");
						shareIntent.putExtra(android.content.Intent.EXTRA_STREAM, Uri.parse("file://"+oldPic));
						shareIntent.putExtra(
						Intent.EXTRA_TEXT,
						Html.fromHtml(new StringBuilder()
						    .append("<p><b>"+oldName+" "+oldSurname+"</b></p>")
						    .append("<p>Company:"+oldCompany+", phone:"+oldPhone+"</p>")
						    .append("<small>You can see my full card at shareCard.me website.</small>")
						    .toString())
						);
						myDialog.dismiss();
						startActivity(shareIntent);
						
					}
				});
				
				Button btnCancel = (Button)myDialog.findViewById(R.id.btnCancel);
				/**
				 * onClick metoda poziva se nakon klika na navedeni gumb.
				 * @param v
				 * @return void
				 */
				btnCancel.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						myDialog.dismiss();
					}
				});
				
			}
		});
	}
}
package hr.sharecard;

import hr.sharecard.database.CardsAdapter;
import hr.sharecard.types.CardInfo;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.AdapterView.OnItemClickListener;
/**
 * Klasa Contacts slu�i za ispis liste kontakata, odnosno vizitki koje je korisnik kreirao i primio od drugih korisnika koriste�i metodu showData().
 * Pomo�u listView komponente realiziran je ispis svih kontakata te je omogu�eno pretra�ivanje istih. Klikom na jedan od kontakata
 * otvara se novi activity za pregled pojedine vizitke.
 * @author Lorena
 *
 */
public class Contacts extends Activity {
	
    EditText inputSearch;
    SimpleAdapter adapter;
    ListView lv;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_contacts);
		
		showData();
		// Listview Data
		inputSearch = (EditText) findViewById(R.id.search);
		
		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override   
			public void onItemClick(AdapterView<?> parent, View clickView,int position, long id) {
	        	String  selectedFromList =  parent.getItemAtPosition(position).toString();
	        	//Toast.makeText(MainActivity.this, String.format("%s was chosen.",selectedFromList),Toast.LENGTH_SHORT).show();
	        	Intent singlecard = new Intent(Contacts.this, Card.class);
	        	singlecard.putExtra("selectedFromList", selectedFromList);
	        	startActivity(singlecard);
			   } 
		});

        
   
        inputSearch.addTextChangedListener(new TextWatcher() {
            
            @Override
           public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                // When user changed the Text
            	adapter.getFilter().filter(cs);
            	
            	
            }
             
            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,int arg3) {
                // TODO Auto-generated method stub
            	
            }

			@Override
			public void afterTextChanged(Editable s) {
				
				
			}
			

        });
    }
	/**
	 * metoda showData() omogu�ava prikaz podataka iz baze na formi
	 * @return void
	 */
	private void showData()
	{
		CardsAdapter cardsAdapter = new CardsAdapter(this);
		List<CardInfo> cards = cardsAdapter.getAllCards();
		
		lv = (ListView)findViewById(R.id.datalist);
		String [] from = new String[] {"pic", "name", "surname", "company", "phone"};
		int[] to = new int[] {R.id.pic, R.id.name, R.id.surname, R.id.company, R.id.phonenumber};
		
		HashMap<String, String> map;
		List<HashMap<String, String>> data;
		data = new ArrayList<HashMap<String,String>>();
		
		Iterator<CardInfo> itr = cards.iterator();
		while(itr.hasNext())
		{
			map = new HashMap<String, String>();
			CardInfo card = itr.next();
			map.put("id",""+ card.getId());
			map.put("name", card.getName());
			map.put("surname", card.getSurname());
			map.put("company", card.getCompany());
			map.put("phone", card.getPhone());
			map.put("pic", card.getPic());
			
			data.add(map);
			
		}
		
		adapter = new SimpleAdapter(this, data, R.layout.activity_carditem, from, to);
		lv.invalidateViews();
		lv.setAdapter(adapter);
		
		
				};
		
	    
		
}
package hr.sharecard;

import hr.sharecard.database.EventsAdapter;
import hr.sharecard.types.EventInfo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class Timeline extends Activity{

	/**
	 * onCreate metoda se poziva odmah nakon startanja klase. 
	 * Unutar ove metode pozivaju se druge metode i inicijaliziraiju varijable.
	 * @param savedInstanceState
	 * @return void
	 */
	public int t_id;
	ListView lv;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_timeline);
		
		final Context context = this;
		 Bundle bn = new Bundle();
    	 bn = getIntent().getExtras();
         Serializable id = bn.getSerializable("id");
         String id2= id.toString();
         final int timeline_id = Integer.parseInt(id2);
	     t_id = timeline_id;
      	Toast.makeText(Timeline.this, String.format("Timeline with id %s was selected",timeline_id),Toast.LENGTH_SHORT).show();	
      	showEvents();
      	
      	
      	lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View clickView,int position, long id) {
				String  selectedFromList =  parent.getItemAtPosition(position).toString();
				
				StringTokenizer tokens = new StringTokenizer(selectedFromList, ",");
				String e_id = tokens.nextToken();
				String artifact = tokens.nextToken();
				String date = tokens.nextToken();
				String desc = tokens.nextToken();
				String event = tokens.nextToken();
				
				StringTokenizer idValue = new StringTokenizer(e_id,"=");
				idValue.nextToken();
				final String oldId = idValue.nextToken();
				//Toast.makeText(context, oldId, Toast.LENGTH_SHORT).show();
				
				StringTokenizer artifactValue = new StringTokenizer(artifact,"=");
				artifactValue.nextToken();
				String oldArtifact = artifactValue.nextToken();
				//Toast.makeText(context, oldArtifact, Toast.LENGTH_SHORT).show();
				
				StringTokenizer descValue = new StringTokenizer(desc,"=");
				descValue.nextToken();
				String oldDesc = descValue.nextToken();
				
				StringTokenizer eventValue = new StringTokenizer(event, "=");
				eventValue.nextToken();
				String oldEvent = eventValue.nextToken().replace("}", "");
				
				final Dialog myDialog = new Dialog(Timeline.this);	
				myDialog.setContentView(R.layout.dialog_addevent);
				myDialog.setTitle("Editing event");
				myDialog.setCancelable(true);
				myDialog.show();
				
			
				final EditText txtEvent = (EditText)myDialog.findViewById(R.id.editEventName);
				final EditText txtDesc = (EditText)myDialog.findViewById(R.id.editEventDesc);
				final EditText txtArtifact = (EditText)myDialog.findViewById(R.id.editEventArtifact);
				
				
				txtEvent.setText(oldEvent);
				txtDesc.setText(oldDesc);
				txtArtifact.setText(oldArtifact);
				
				Button btnSave = (Button)myDialog.findViewById(R.id.btnSaveEvent);
				btnSave.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						EventsAdapter eventsAdapter = new EventsAdapter(context);
						String newEvent = txtEvent.getText().toString();
						String newDesc = txtDesc.getText().toString();
						String newArtifact = txtArtifact.getText().toString();
						DatePicker datePicker = new DatePicker(context);
						datePicker = (DatePicker)myDialog.findViewById(R.id.datePicker);
						int year= datePicker.getYear();
						int month = datePicker.getMonth();
						int day = datePicker.getDayOfMonth();
						CharSequence text = "" + year + "-" + "" + month + "-" + ""
			                    + day;
						String newDate = text.toString();
						
						
						
						
						boolean ok = eventsAdapter.updateEvent(oldId, newEvent, newDesc, newDate, newArtifact);
						Toast.makeText(context, ok ? "Event updated!" : "Error", Toast.LENGTH_LONG).show();
						myDialog.dismiss();
						
					
						setResult(RESULT_OK, null);
						finish();
					
					}
				});
				
				Button btnCancel = (Button)myDialog.findViewById(R.id.btnCancelEvent);
				btnCancel.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						myDialog.dismiss();
						
					}
				});
				
		      	
		      	
			}
		});
      	
      	lv.setOnItemLongClickListener(new OnItemLongClickListener() {

			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View clickView,int position, long id) {
				DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
				    @Override
				    public void onClick(DialogInterface dialog, int which) {
				        switch (which){
				        case DialogInterface.BUTTON_POSITIVE:
				        	setResult(RESULT_OK, null);
							finish();
							
				            break;

				        case DialogInterface.BUTTON_NEGATIVE:
				            //No button clicked
				            break;
				        }
				    }
				};
				AlertDialog.Builder builder = new AlertDialog.Builder(context);
				builder.setMessage("Are you sure you want to delete?").setPositiveButton("Yes", dialogClickListener)
				    .setNegativeButton("No", dialogClickListener).show();
				
				String  selectedFromList =  parent.getItemAtPosition(position).toString();
				StringTokenizer tokens = new StringTokenizer(selectedFromList, ",");
				String e_id = tokens.nextToken();
				StringTokenizer idValue = new StringTokenizer(e_id,"=");
				idValue.nextToken();
				final String Event_id = idValue.nextToken();
				EventsAdapter eventsAdapter = new EventsAdapter(context);
				return eventsAdapter.deleteEvent(Event_id);
				
			}
		});
      	
      	
      	Button btnAddEvent = (Button)findViewById(R.id.btnAddevent);
      	btnAddEvent.setOnClickListener(new OnClickListener() {
      		
			@Override
			public void onClick(View v) {
				final Dialog myDialog = new Dialog(Timeline.this);	
				myDialog.setContentView(R.layout.dialog_addevent);
				myDialog.setTitle("Add event");
				myDialog.setCancelable(true);
				myDialog.show();
				
				
				Button btnSave = (Button)myDialog.findViewById(R.id.btnSaveEvent);
				btnSave.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						EditText txteventName = (EditText)myDialog.findViewById(R.id.editEventName);
						EditText txteventDesc = (EditText)myDialog.findViewById(R.id.editEventDesc);
						EditText txteventArtifact = (EditText)myDialog.findViewById(R.id.editEventArtifact);
						
						
						String event_name = txteventName.getText().toString();
						String event_desc = txteventDesc.getText().toString();
						String event_artifact = txteventArtifact.getText().toString();
						
						
						DatePicker datePicker = new DatePicker(context);
						datePicker = (DatePicker)myDialog.findViewById(R.id.datePicker);
						int year= datePicker.getYear();
						int month = datePicker.getMonth();
						int day = datePicker.getDayOfMonth();
						CharSequence text = "" + year + "-" + "" + month + "-" + ""
			                    + day;
						String date = text.toString();
						
						
						EventInfo newEvent = new EventInfo();
						
						newEvent.setEventName(event_name);
						newEvent.setEventDesc(event_desc);
						newEvent.setEventArtifact(event_artifact);
						newEvent.setEventDate(date);
						newEvent.setTimeline_id(timeline_id);
						
											
						
						EventsAdapter eventAdapter = new EventsAdapter(context);
						long r = eventAdapter.insertEvent(newEvent);
						
						Toast.makeText(context, 
							r != 0 ? "Event Added!" : "Error!", 
								Toast.LENGTH_LONG).show();
						myDialog.dismiss();
						setResult(RESULT_OK, null);
						finish();
					
					}
				});
				
				Button btnCancel = (Button)myDialog.findViewById(R.id.btnCancelEvent);
				btnCancel.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						myDialog.dismiss();
						
					}
				});
				
			}
		});
      	
      	
      	
      	
	}
      	private void showEvents(){
	
			EventsAdapter eventsAdapter = new EventsAdapter(this);
			List<EventInfo> events = eventsAdapter.getAllEvent();
			
			lv = (ListView)findViewById(R.id.lvmyevents);
		
			String [] from = new String[] {"name", "description", "date"};
			int[] to = new int[] {R.id.eventname, R.id.eventdesc, R.id.eventdate};
			
			HashMap<String, String> map;
			List<HashMap<String, String>> data;
			data = new ArrayList<HashMap<String,String>>();
			
			Iterator<EventInfo> itr = events.iterator();
			while(itr.hasNext())
			{
				map = new HashMap<String, String>();
				EventInfo event = itr.next();
				if (event.getTimeline_id()==t_id){
				
				map.put("id",""+ event.getEventid());
				map.put("name", event.getEventName());
				map.put("description", event.getEventDesc());
				map.put("date", event.getEventDate());
				map.put("artifact", event.getEventArtifact());
				data.add(map);
			}
				
				
			
			
			SimpleAdapter adapter = new SimpleAdapter(this, data, R.layout.activity_myevents, from, to);
			lv.invalidateViews();
			lv.setAdapter(adapter);

			}
      	
			
      	
      	}
}

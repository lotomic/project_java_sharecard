package hr.sharecard.interfaces;
/**
 * klasa za mobilni servis
 * @author Lorena
 *
 */
public class MobileService {

}

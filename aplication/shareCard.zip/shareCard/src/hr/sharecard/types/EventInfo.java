package hr.sharecard.types;

public class EventInfo {
	private String eventName;
	private String eventDesc;
	private String eventDate;
	private String eventArtifact;
	private int eventid;
	private int timeline_id;
	
	
	public int getTimeline_id() {
		return timeline_id;
	}
	public void setTimeline_id(int timeline_id) {
		this.timeline_id = timeline_id;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getEventDesc() {
		return eventDesc;
	}
	public void setEventDesc(String eventDesc) {
		this.eventDesc = eventDesc;
	}
	public String getEventDate() {
		return eventDate;
	}
	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}
	public String getEventArtifact() {
		return eventArtifact;
	}
	public void setEventArtifact(String eventArtifact) {
		this.eventArtifact = eventArtifact;
	}
	public int getEventid() {
		return eventid;
	}
	public void setEventid(int eventid) {
		this.eventid = eventid;
	}
}

package hr.sharecard.types;
/**
 * klasa koja definira Card tip podataka
 * @author Lorena
 *
 */
public class CardInfo {
	private String name;
	private String surname;
	private String company;
	private String phone;
	private String email;
	private String pic;
	private int id;
	
	/**
	 * getter za varijablu company
	 * @return company
	 */
	public String getCompany() {
		return company;
	}
/**
 * setter za varijablu company
 * @param company
 */
	public void setCompany(String company) {
		this.company = company;
	}
/**
 * getter za varijablu phone
 * @return phone
 */
	public String getPhone() {
		return phone;
	}
/**
 * setter za varijablu phone
 * @param phone
 */
	public void setPhone(String phone) {
		this.phone = phone;
	}	
/**
 * getter za varijablu name
 * @return name
 */
	public String getName() {
		return name;
	}
/**
 * setter za varijablu name
 * @param name
 */
	public void setName(String name) {
		this.name = name;
	}
/**
 * getter za varijablu surname
 * @return surname
 */
	public String getSurname() {
		return surname;
	}
/**
 * setter za varijablu surname
 * @param surname
 */
	public void setSurname(String surname) {
		this.surname = surname;
	}
/**
 * getter za varijablu email
 * @return email
 */
	public String getEmail() {
		return email;
	}
/**
 * setter za varijablu email
 * @param email
 */
    public void setEmail(String email) {
		this.email = email;
	}
	
	/**
	 * getter za varijablu pic
	 * @return email
	 */
	public String getPic() {
		return pic;
	}
	/**
	 * setter za varijablu pic
	 * @param email
	 */
	public void setPic(String pic) {
		this.pic = pic;
	}
/**
 * getter za varijablu id
 * @return id
 */
	public int getId()
	{
		return id;
	}
/**
 * setter za varijablu id
 * @param id
 */
	public void setId(int id)
	{
		this.id = id;
	}
}

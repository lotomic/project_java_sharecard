package hr.sharecard;

import hr.sharecard.database.CardsAdapter;
import hr.sharecard.types.CardInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
/**
 * <p>
 * Ovo je glavna klasa MainActivity koja pro�iruje Activity
 * </p>
 * @author Jakov
 *
 */
public class MainActivity extends Activity {
	/**
	 * @author Jakov
	 * @param Bundle savedInstanceState
	 * @return void
	 */
	private Context context;
	
	/**
	 * onCreate metoda se poziva odmah nakon startanja klase. 
	 * Unutar ove metode pozivaju se druge metode i inicijaliziraiju varijable.
	 * @param savedInstanceState
	 * @return void
	 */
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		context = this;
		
		showCards();
		
		Button btnCreate = (Button)findViewById(R.id.btnCreate);
		btnCreate.setOnClickListener(new OnClickListener() {
			
			/**
			 * onClick metoda poziva se nakon klika na navedeni gumb.
			 * @param v
			 * @return void
			 */
			@Override
			public void onClick(View v) {
				Intent i = new Intent(MainActivity.this, CreateCard.class);
				startActivityForResult(i,1);
			}
		});
		
		//Button za kontakte
		Button btnContacts = (Button)findViewById(R.id.btnContacts);
		btnContacts.setOnClickListener(new OnClickListener() {
			
			/**
			 * onClick metoda poziva se nakon klika na navedeni gumb.
			 * @param v
			 * @return void
			 */
			@Override
			public void onClick(View v) {
				Intent i = new Intent(MainActivity.this, Contacts.class);
				startActivityForResult(i,1);
			}
		});
		
	}

	/**
	 * showCards dohvaca podatke iz CardsAdapter klase i prikazuje ih unutar liste.
	 * @return void
	 */
	
	private void showCards(){
		
			CardsAdapter cardsAdapter = new CardsAdapter(this);
			List<CardInfo> cards = cardsAdapter.getMyCards();
			
			ListView lv = (ListView)findViewById(R.id.mycardsdatalist);
			String [] from = new String[] {"pic", "name", "surname", "company", "phone"};
			int[] to = new int[] {R.id.pic, R.id.name, R.id.surname, R.id.company, R.id.phonenumber};
			
			HashMap<String, String> map;
			List<HashMap<String, String>> data;
			data = new ArrayList<HashMap<String,String>>();
			
			Iterator<CardInfo> itr = cards.iterator();
			while(itr.hasNext())
			{
				map = new HashMap<String, String>();
				CardInfo card = itr.next();
				map.put("id",""+ card.getId());
				map.put("name", card.getName());
				map.put("surname", card.getSurname());
				map.put("company", card.getCompany());
				map.put("phone", card.getPhone());
				map.put("pic", card.getPic());
				data.add(map);
				
			}
			
			SimpleAdapter adapter = new SimpleAdapter(this, data, R.layout.activity_mycards, from, to);
			lv.invalidateViews();
			lv.setAdapter(adapter);
						
			lv.setOnItemClickListener(new OnItemClickListener(){
				@Override   
				public void onItemClick(AdapterView<?> parent, View clickView,int position, long id) {
		        	String  selectedFromList =  parent.getItemAtPosition(position).toString();
		        	//Toast.makeText(MainActivity.this, String.format("%s was chosen.",selectedFromList),Toast.LENGTH_SHORT).show();
		        	Intent singlecard = new Intent(MainActivity.this, Card.class);
		        	singlecard.putExtra("selectedFromList", selectedFromList);
		        	startActivityForResult(singlecard,1);
				   } 
			});
	}
	
	/**
	 * onCreateOptionsMenu kreira izbornik na poziv sistemske tipke.
	 * @param menu
	 * @return true
	 */
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	/**
	 * onOptionsItemSelected pokre�e nove aktivnosti nakon odabira jedne od opcija izbornika.
	 * @param item
	 * @return true
	 */
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.action_settings:
			Intent i = new Intent(this, SettingsActivity.class);
			startActivity(i);
			break;
		}
		
		return true;
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	      super.onActivityResult(requestCode, resultCode, data);
	      if(resultCode==RESULT_OK){
	         Intent refresh = new Intent(this, MainActivity.class);
	         startActivity(refresh);
	         this.finish();
	      }
	      
	}

}

package hr.sharecard;

import hr.sharecard.database.CardsAdapter;
import hr.sharecard.types.CardInfo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

public class SplashScreen extends Activity {

	private static int SPLASH_TIME_OUT = 2000;
	
	/**
	 * onCreate metoda se poziva odmah nakon startanja klase. 
	 * Unutar ove metode pozivaju se druge metode i inicijaliziraiju varijable.
	 * @param savedInstanceState
	 * @return void
	 */
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splashscreen);

		
		new Handler().postDelayed(new Runnable() {
			/**
			 * run metoda pokrece i izvrsava zadatak u odre�enom vremenu. 
			 * U ovom slu�aju vrijeme je definirano u varijabli SPLASH_TIME_OUT
			 * @return void
			 */
            @Override
            public void run() {
        		
            	String path = null;
            	StringBuilder total = new StringBuilder(); 
            	
            	try {
            		final Context context = SplashScreen.this;
	        		Intent intent = getIntent();
	        		Uri uri = intent.getData();
	        		path = uri.getPath();
	        		
	        		File file = new File(path);
	        		InputStream inputStream = new FileInputStream(file);
	        		BufferedReader r = new BufferedReader(new InputStreamReader(inputStream));
	        		String line; 

	        		while ((line = r.readLine()) != null) {
	        		   total.append(line);
	        		}
	        		
	            	 
	            	String[] parts = total.toString().split("b");
	            	String[] partsb = parts[1].toString().split("b");
	            	String[] partsc = partsb[0].toString().split(">");
	            	String[] partsd = partsc[1].toString().split("<");
	            	
	                String[] partse = partsd[0].toString().split(",");
	                String[] nameparts = partse[0].split(":");
	                String[] surnameparts = partse[1].split(":");
	                String[] companyparts = partse[2].split(":");
	                String[] phoneparts = partse[3].split(":");
	                      	
	              	final String Name = nameparts[1];
	              	final String Surname = surnameparts[1];
	              	final String Company = companyparts[1];
	              	final String Phone = phoneparts[1];
	              	
	              	CardsAdapter cardsAdapter = new CardsAdapter(context);
	              	CardInfo newCard = new CardInfo();
	              	newCard.setName(Name);
					newCard.setSurname(Surname);
					newCard.setCompany(Company);
					newCard.setPhone(Phone);
	              	cardsAdapter.sharedCard(newCard);
	            	
	            	} catch (Exception e){ 
	           	 }
            	
              	//Toast.makeText(SplashScreen.this, String.format("Name:"+Name+",Surname"+Surname+",Company"+Company+",Phone"+Phone),Toast.LENGTH_LONG).show();	
                Intent i = new Intent(SplashScreen.this, MainActivity.class);
    			startActivity(i);
    			
                finish();
            }
        }, SPLASH_TIME_OUT);
	}
	
}
